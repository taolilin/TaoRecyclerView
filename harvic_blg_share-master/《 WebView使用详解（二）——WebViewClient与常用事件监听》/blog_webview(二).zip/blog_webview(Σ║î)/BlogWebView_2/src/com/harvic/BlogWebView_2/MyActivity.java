package com.harvic.BlogWebView_2;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.KeyEvent;
import android.webkit.WebView;

public class MyActivity extends Activity {
    private WebView mWebView;

    private ProgressDialog mProgressDialog;
    private String TAG = "qijian";
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        mWebView = (WebView)findViewById(R.id.webview);
        mProgressDialog = new ProgressDialog(this);
        mWebView.getSettings().setJavaScriptEnabled(true);

//        mWebView.setWebViewClient(new WebViewClient());

//        mWebView.setWebViewClient(new WebViewClient(){
//            @Override
//            public boolean shouldOverrideUrlLoading(WebView view, String url) {
//                if (url.contains("blog.csdn.net")){
//                    view.loadUrl("http://www.baidu.com");
//                }else {
//                    view.loadUrl(url);
//                }
//                return true;
//            }
//        });

//
//        mWebView.setWebViewClient(new WebViewClient(){
//
//            @Override
//            public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
//                try {
//                    if (url.equals("http://localhost/qijian.png")) {
//                        AssetFileDescriptor fileDescriptor =  getAssets().openFd("s07.jpg");
//                        InputStream stream = fileDescriptor.createInputStream();
//                        WebResourceResponse response = new WebResourceResponse("image/png", "UTF-8", stream);
//                        return response;
//                    }
//                }catch (Exception e){
//                    Log.e(TAG,e.getMessage());
//                }
//                return super.shouldInterceptRequest(view, url);
//            }
//
//            @Override
//            public boolean shouldOverrideUrlLoading(WebView view, String url) {
////                if (url.contains("blog.csdn.net")){
////                    view.loadUrl("http://www.baidu.com");
////                }
//                return false;
//            }
//
//            @Override
//            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
////                super.onReceivedSslError(view, handler, error);
//                handler.proceed();
//                Log.e(TAG,"sslError:"+error.toString());
//            }
//
//            @Override
//            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
//                super.onReceivedError(view, errorCode, description, failingUrl);
//                mWebView.loadUrl("file:///android_asset/error.html");
//                Log.e(TAG,"onReceivedError:"+errorCode+"  "+description);
//            }
//
//            @Override
//            public void onPageStarted(WebView view, String url, Bitmap favicon) {
//                super.onPageStarted(view, url, favicon);
//                mProgressDialog.show();
//            }
//
//            @Override
//            public void onPageFinished(WebView view, String url) {
//                super.onPageFinished(view, url);
//                mProgressDialog.hide();
//            }
//        });

        mWebView.loadUrl("http://blog.csdn.net/harvic880925/");
//        mWebView.loadUrl("https://www.12306.cn/");
//        mWebView.loadUrl("file:///android_asset/web.html");
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        //改写物理返回键的逻辑
        if(keyCode==KeyEvent.KEYCODE_BACK) {
            if(mWebView.canGoBack()) {
                mWebView.goBack();//返回上一页面
                return true;
            } else {
                System.exit(0);//退出程序
            }
        }
        return super.onKeyDown(keyCode, event);
    }
}
